﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20231206
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 1, 9, 5,6,4,2,5};
            int sum = 0;
            
            for (int i = 0;i < a.Length; i++) 
            {
                sum += i;
            }
            sum = 0;
            foreach (int i in a) 
            {
                sum += i;
                Console.Write(i + "\t");
            }
            Console.WriteLine();
            Console.WriteLine($"加總: {sum}");

            Console.ReadLine();
            

        }
    }
}
