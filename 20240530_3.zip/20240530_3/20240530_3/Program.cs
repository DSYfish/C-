﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20240530_3
{
    internal class Program
    {
        static void intFactor(int n,int f)
        {
            if (n < 2)
                return;
            if (n % f == 0)
            {
                Console.Write(f + " ");
                intFactor(n/f,f);
            }
            else
            {
                intFactor(n,f+1);
            }
        }
        static void Main(string[] args)
        {
            int n = 120;
            n = int.Parse(Console.ReadLine());
            intFactor(n,2);

            Console.ReadKey();
        }
    }
}
